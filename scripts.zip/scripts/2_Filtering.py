# !usr/bin/env python3
import re
from tkinter import *
from tkinter import filedialog
import os
import sys
import datetime
import collections


#------------------------Functions--------------------------------------------#
def recuento_bases_repetidas(x):  #x tiene que ser un contig
    occurrences = collections.Counter(bases_ocupadas_real[x])
    count0 = 1
    list_interna=[]
    for base,count in occurrences.items():
        if count == count0:
            continue
        else:
            list_interna.append(base)
            count0 = count
    return list_interna

def recuento_bases_repetidas(x):  #x tiene que ser un contig
    occurrences = collections.Counter(bases_ocupadas_real[x])
    count0 = 1
    list_interna=[]
    for base,count in occurrences.items():
        if count == count0:
            continue
        else:
            list_interna.append(base)
            count0 = count
    return list_interna

def add_ORF(ORF,line,pbi,pbf,contig):
    ORFs_definitivos[ORF]=line
    for i in range(pbi-50,pbf+53): #OJO con ese + 3 porque si arreglo el archivo de anotacion inicial puede cambar. Agregue el 50 pb el 30-06-221
        bases_ocupadas[contig].append(i)
    for i in range(pbi,pbf+3):
        bases_ocupadas_real[contig].append(i)

def process_line(line):
    global contig
    global gffdescripcion
    global score
    global ORF
    global pbi
    global pbf
    global cov1
    global cov2
    global idn
    global holoORF_OK
    line1 = line.split('\t')
    contig= line1[0]
    if contig not in bases_ocupadas.keys():
        bases_ocupadas[contig]=[]
        bases_ocupadas_real[contig]=[]
    gffdescripcion = line1[8].strip()
    bloques_descripcion = gffdescripcion.split(";")
    linescore= bloques_descripcion[7]
    sscore=linescore.split('=')
    score=sscore[1]
    ORF= bloques_descripcion[0][3:]
    holoORF=ORF.split("_")
    holoORF.pop()
    holoORF_OK="_".join(holoORF) #holoORF para comparar cual es el mejor RA_XX_XX sin el ultimo quion bajo
    pbi=int(line1[3])
    pbf=int(line1[4])
    coverages=bloques_descripcion[5].split(",")
    cov1=float(coverages[0][5:])
    cov2=float(coverages[1][5:])
    idn=float(bloques_descripcion[4][4:])


root = Tk()
a= filedialog.askopenfilename(title= "Select GFF (output of script 1)")
Test_file=open(a)
print(a)

cepaaanotar=input('Write strain name: ')

#-----------------------------------------------------------------#
Pos= 'grep -F "+" %s | sort -k 1,1 -k4n > FileOrderedPos.gff' % (a)
Neg= 'grep -Fv "+" %s | sort -k 1,1 -k5nr > FileOrderedNeg.gff' % (a)
PosNeg='cat FileOrderedPos.gff FileOrderedNeg.gff  > FilePosNegOrdered.gff'
NegPos='cat  FileOrderedNeg.gff  FileOrderedPos.gff > FileNegPosOrdered.gff'
os.system(Pos)
os.system(Neg)
os.system(PosNeg)
os.system(NegPos)

#eliminar archivos de tipo base de datos. nih..
rm1 = 'rm FileOrderedPos.gff'
rm2 = 'rm FileOrderedNeg.gff'
os.system(rm1)
os.system(rm2)


#-------------------Seccion de filtro de bases------------------------#

#print('=====Este script filtra archivos .gff quedandose con lo que mejor define cierto rango de bases=====')
root = Tk()
archivogff1=open('FilePosNegOrdered.gff')
archivogff2=open('FileNegPosOrdered.gff')

GFFs=[archivogff1,archivogff2]
for number,file in enumerate(GFFs):
    #en este diccionario van los que si o si son buenos alineamientos.La Key es el ORF y el value es toda la info del gff
    ORFs_definitivos={}
    #en este diccionario se guardan las bases 'ocupadas de los contigs'.Las Key es el contig y el value es una lista de cada base ocupada
    bases_ocupadas={}
    bases_ocupadas_real={} #este es para ver si se solapan ORF realmente
    #en esta lista se guardan los nombres de los contigs anotados
    contigs_anotados=[]
    #Primero anoto todos los que son score_pred=0 que esos si o si ganan siempre y anoto esas bases
    orfs_score2={}
    for line in file:
        process_line(line)
        if score=="0" and 'is_pseudo=true' not in gffdescripcion and pbi not in bases_ocupadas[contig] and pbf not in bases_ocupadas[contig]:
            add_ORF(ORF,line,pbi,pbf,contig)
    file.seek(0) #esto es para leer el archivo mas de una vez
    #====================================================================
    #ahora anoto los que tienen scorepred=1 dentro de los gaps que dejo el score_pred=0
    for line in file:
        process_line(line)
        if score=="1" and 'is_pseudo=true' not in gffdescripcion:
            if pbi not in bases_ocupadas[contig] and pbf not in bases_ocupadas[contig]:
                add_ORF(ORF,line,pbi,pbf,contig)
    #====================================================================
    #ahora anoto los que tienen scorepred=2 dentro de los gaps que dejo el score_pred=0 y 1
    file.seek(0)
    for line in file:
        process_line(line)
        if score=="2" and 'is_pseudo=true' not in gffdescripcion:
            if pbi not in bases_ocupadas[contig] and pbf not in bases_ocupadas[contig]:
                #reescribo el ORF de score 2 si tiene mejores parametros
                if contig not in orfs_score2.keys():
                    orfs_score2[contig]={}
                if holoORF_OK not in orfs_score2[contig].keys():
                    orfs_score2[contig][holoORF_OK]={"Line":line,"idn": idn , "cov1": cov1 , "cov2": cov2, "ORF":ORF, "pbi": pbi,"pbf":pbf, "contig":contig }
                else:
                    perc_idn_old=orfs_score2[contig][holoORF_OK]["idn"]
                    cov1_old=orfs_score2[contig][holoORF_OK]["cov1"]
                    cov2_old=orfs_score2[contig][holoORF_OK]["cov2"]
                    if idn>=perc_idn_old and cov1>= cov1_old and cov2>= cov2_old:
                        orfs_score2[contig][holoORF_OK]={"Line":line,"idn": idn , "cov1": cov1 , "cov2": cov2, "ORF":ORF, "pbi": pbi,"pbf":pbf, "contig":contig }
    file.seek(0)
    # for contig, ORF in orfs_score2.items():
    #     print(contig,ORF)
    #======================escribir archivos===========================================
    if number==0:
        filename="PosNegOrdered-filtered.gff"
    else:
        filename="NegPosOrdered-filtered.gff"
    out= open(filename,'w+')
    #out.write('##gff-version 3')
    ##Migrate orfs_score2 to ORFs_definitivos
    for contig,ORFS in orfs_score2.items():
        for holoORF,detalle in ORFS.items():
            add_ORF(detalle["ORF"],detalle['Line'],detalle["pbi"],detalle["pbf"],detalle["contig"])

    for k,v in ORFs_definitivos.items():
        v=v.strip()
        out.write(v)
        out.write("\n")

    # print('====================Analizando bases ocupadas===========================')
    for k,v in ORFs_definitivos.items():
        num_contig= k.split('_')[1]
        contig=cepaaanotar+"_"+num_contig
        if contig not in contigs_anotados:
            contigs_anotados.append(contig)
            # print('Contig anotado')
            bases_a_analizar= recuento_bases_repetidas(contig)
            # print(contig)
            # print(bases_a_analizar)
    file.close()
rm1 = 'rm FilePosNegOrdered.gff'
rm2 = 'rm FileNegPosOrdered.gff'
os.system(rm1)
os.system(rm2)
#-----------------------------MERGE STRANDS--------------------------------------

archivogff1=open('PosNegOrdered-filtered.gff')
archivogff2=open('NegPosOrdered-filtered.gff')


######################  MERGING GFF FILES #########################################3

diccionario_anotacion={} #tiene las lineas del gff que quedan en el archivo final
lista_CDS=[] # lista de los CDSs anotados, sin discriminar por contig
bases_ocupadas_real={}

for line in archivogff1:
    #print(line)
    line1 = line.split('\t')
    pbi=int(line1[3])
    pbf=int(line1[4])
    strand=line1[6]
    #print(pbi,pbf,strand)
    if strand=="+":
        pbf=pbf+3
    else:
        pbi=pbi-3
    #print(pbi,pbf,strand)
    line1[3]=pbi#this line fixes the missing STOP codon
    line1[4]=pbf #this line fixes the missing STOP codon
    #print(line1)
    contig= line1[0]
    gffdescription = line1[8]
    bloques_description = gffdescription.split(";")
    id_CDS=bloques_description[0][3:]
    lista_CDS.append(id_CDS) # guardo el CDS en la lista
    #Lea y guarde todos los CDSs anotados en una lista
    if contig not in diccionario_anotacion.keys():
        diccionario_anotacion[contig]=[]
    diccionario_anotacion[contig].append(line1)
    #ocupar las bases
    if contig not in bases_ocupadas_real.keys():
        bases_ocupadas_real[contig]=[]
    for i in range(pbi,pbf):
        bases_ocupadas_real[contig].append(i)

overlapping=0
for line in archivogff2:
    #print(line)
    line1 = line.split('\t')
    gffdescription = line1[8]
    bloques_description = gffdescription.split(";")
    id_CDS=bloques_description[0][3:]
    contig= line1[0]
    if id_CDS not in lista_CDS:
        lista_CDS.append(id_CDS)
        overlapping+=1
        pbi=int(line1[3])
        pbf=int(line1[4])
        strand=line1[6]
        #print(pbi,pbf,strand)
        if strand=="+":
            pbf=pbf+3
        else:
            pbi=pbi-3
        line1[3]=pbi#this line fixes the missing STOP codon
        line1[4]=pbf #this line fixes the missing STOP codon
        diccionario_anotacion[contig].append(line1)
        for i in range(pbi,pbf):
            bases_ocupadas_real[contig].append(i)

rm1 = 'rm PosNegOrdered-filtered.gff'
rm2 = 'rm NegPosOrdered-filtered.gff'
os.system(rm1)
os.system(rm2)


out= open("final.gff",'w+')
out2= open("repeated_bases.txt",'w+')
# print('====================Writing gff==========================')

for contig,CDSss in diccionario_anotacion.items():
    #print(contig)
    for each_CDS in CDSss:
        GFFclasicotab= ('\t').join(str(n) for n in each_CDS)
        out.write(GFFclasicotab)

# print('====================Occupied bases===========================')
cant_contigs_repeatedbases=0
cant_contigs_nonrepeatedbases=0
for contig,bases in bases_ocupadas_real.items():
    bases_a_analizar= recuento_bases_repetidas(contig)
    if len(bases_a_analizar) != 0:
        out2.write(contig)
        out2.write("\n")
        out2.write(str(bases_a_analizar))
        out2.write("\n")
        cant_contigs_repeatedbases+=1
    else:
        cant_contigs_nonrepeatedbases+=1

total=cant_contigs_repeatedbases+cant_contigs_nonrepeatedbases
out2.write('------Number of overlapping CDS: %s-----'% overlapping)
out2.write("\n")
out2.write('------Contigs with repeated bases:     %s-----'% cant_contigs_repeatedbases)
out2.write("\n")
out2.write('------Contigs without repeated bases:     %s-----'% cant_contigs_nonrepeatedbases)
out2.write("\n")
out2.write('------------------Total contigs:     %s-----'% total)

# print('This process took...')
# print(datetime.datetime.now() -inicio)
