from tkinter import *
from tkinter import filedialog

import datetime
inicio= datetime.datetime.now()


c= filedialog.askopenfilename(title= "Select file database used as database for BLASTN (FASTA):")
DB_pseudo=open(c)
print(c)
#

a= filedialog.askopenfilename(title= "Select GFF file (output of script 2):")
archivogff=open(a)
print(a)


b= filedialog.askopenfilename(title= "Select BLASTN file:")
BLASTn=open(b)
print(b)

def def_strand(x,y): #x=pbi, y=pbf
    if x>y:
        strand='-'
    else:
        strand='+'
    return strand

def def_coverage(len_alin,len_subject):
    result=round(((int(len_alin)/int(len_subject))*100),2)
    if result >= 100:
        return 100.00
    else:
        return result

def def_section(pbi,pbf,strand,len_query,len_alin,cover):
    cover=int(cover)
    if cover < 50:
        if strand=='+':
            if pbi <= 60:   #pbi cercana a 1
                section='-N-ter'
            elif pbf> (len_query-60): #pbf cercana a len_query
                section='-C-ter'
            else:
                section=''
        elif strand=="-":
            if pbf <= 60:   #pbf cercana a 1
                section='-N-ter'
            elif pbf> (len_query-60): #pbi cercana a len_query
                section='-C-ter'
            else:
                section=''
        return section
    else:
        return ''



bases_ocupadas_real={}
#leo los ORFs curados en ADN y guardo la info de a que corresponden en diccionarios para la anotacion de los pseudo
ORFs_DB= {}
# print('Saving ORFs from DB')
for line in DB_pseudo:
    if line.startswith('>'):
        list5= line.split('|')
        ID= list5[0][1:-1] # ID
        organism0= list5[3] #organism
        organism= organism0.split('=')[1]
        gene_product0= list5[4][1:-1]
        gene_product= gene_product0.split('=')[1]
        ORFs_DB[ID]=[gene_product,organism]


#lee y ocupa las bases que tienen CDSs
for line in archivogff:
    line1 = line.split('\t')
    pbi=int(line1[3])-30 #avoids overlapping between genes and pseudogenes
    pbf=int(line1[4])+30 #avoids overlapping between genes and pseudogenes
    contig= line1[0]
    if contig not in bases_ocupadas_real.keys():
        bases_ocupadas_real[contig]=[]
    for i in range(pbi,pbf):
        bases_ocupadas_real[contig].append(i)

# for contig,list in bases_ocupadas_real.items():
#     if contig =="RA_2517":
#         print(contig,list)


print('GFF file scanned OK')

print("Reading BLASTn...")
gff_pseudo= {}
lastnum={} #dict with last n in contig
for line in BLASTn:
        hit=[]
        line=line.strip()
        line1 = line.split('\t')
        contig= line1[0]
        if contig not in lastnum.keys():
            lastnum[contig]=0
        if contig not in gff_pseudo.keys():
            gff_pseudo[contig]={}
        if contig not in bases_ocupadas_real.keys():
            bases_ocupadas_real[contig]=[]
        homolog = line1[1]
        func_anottation= ORFs_DB[homolog][0]
        organism= ORFs_DB[homolog][1]
        perc_idn=float(line1[2])
        len_alin=int(line1[3])
        pbi_sub=int(line1[6])
        pbf_sub=int(line1[7])
        pbi_query=int(line1[8])
        pbf_query=int(line1[9])
        strand= def_strand(pbi_query, pbf_query)
        query_len=int(line1[12])
        cover= def_coverage(len_alin,query_len)
        mid_base=int((pbi_sub+pbf_sub)/2)
        section= def_section(pbi_query,pbf_query,strand,query_len,len_alin,cover)
        if pbi_sub not in bases_ocupadas_real[contig] and pbf_sub not in bases_ocupadas_real[contig] and mid_base not in bases_ocupadas_real[contig] and cover>20:
            gff_pseudo[contig][lastnum[contig]] = [contig,'BLASTn','pseudogene',pbi_sub, pbf_sub,'.',strand, '.' , 'homolog='+homolog+ ";idn="+str(perc_idn)+';cov='+str(cover)+';gene_product='+func_anottation+section+'_pseudogene;is_pseudo=true']
            lastnum[contig]+=1
            for i in range(pbi_sub,pbf_sub):
                bases_ocupadas_real[contig].append(i)

out_file= a[:-4]+"_pseudogenes.gff"
with open(out_file, 'w') as o:
    for k,v in gff_pseudo.items():
            for kk,vv in v.items():
                GFFclasicotab= ('\t').join(str(n) for n in vv)
                o.write(GFFclasicotab)
                o.write('\n')
                #primero escribo todos los hits que no se superpongan con lo anotado en CDS
                #definir Nter y C-ter
                #los peptidos señal tienen .40 aa aprox, los GPI tienen menos de 40 aa
BLASTn.close()
archivogff.close()
DB_pseudo.close()

