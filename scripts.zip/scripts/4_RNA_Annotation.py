from tkinter import *
from tkinter import filedialog

import datetime
inicio= datetime.datetime.now()

data = {
    'ncRNA': ['C/D small nucleolar RNA (snoRNA)', 'H/ACA snoRNA', 'small nuclear RNA (snRNA) U1', 'small nuclear RNA (snRNA) U3', 'small nuclear RNA (snRNA) U6', 'small nuclear RNA (snRNA) U2', 'spliced leader mini-exon transcript', 'small nuclear RNA (snRNA) U5', 'small nuclear RNA (snRNA) U4'],
    'tRNA': ['tRNA-Cys', 'tRNA-Gln', 'tRNA-Ile', 'tRNA-Leu', 'tRNA-Ser', 'tRNA-Ala', 'tRNA-Arg', 'tRNA-Phe', 'tRNA-Glu', 'tRNA-Val', 'tRNA-Asn', 'tRNA-Lys', 'tRNA-Gly', 'tRNA-Thr', 'tRNA-Trp', 'tRNA-Asp', 'tRNA-Met', 'tRNA-Tyr', 'tRNA-Pro', 'tRNA-His'],
    'rRNA': ['5S ribosomal RNA', 'Large subunit ribosomal RNA, LSU-srRNA4', 'Large subunit ribosomal RNA, LSU-srRNA3', 'Large subunit ribosomal RNA, LSU-srRNA2', '18S ribosomal RNA', '5.8S ribosomal RNA', 'Large subunit ribosomal RNA', 'Large subunit ribosomal RNA, LSU-srRNA1']
}


c= filedialog.askopenfilename(title= "Select file database used as database for BLASTN (FASTA):")
DB_RNA=open(c)
print(c)
#

b= filedialog.askopenfilename(title= "Select BLASTN file:")
BLASTn=open(b)
print(b)

def check_type(input, dict):
    result="Not Match"
    for tipo,lista in dict.items():
        if input in lista:
            result= tipo
    return result

def def_strand(x,y): #x=pbi, y=pbf
    if x>y:
        strand='-'
    else:
        strand='+'
    return strand

def def_coverage(len_alin,len_subject):
    result=round(((int(len_alin)/int(len_subject))*100),2)
    if result >= 100:
        return 100.00
    else:
        return result

def def_section(pbi,pbf,strand,len_query,len_alin,cover):
    cover=int(cover)
    if cover < 50:
        if strand=='+':
            if pbi <= 60:   #pbi cercana a 1
                section='-N-ter'
            elif pbf> (len_query-60): #pbf cercana a len_query
                section='-C-ter'
            else:
                section=''
        elif strand=="-":
            if pbf <= 60:   #pbf cercana a 1
                section='-N-ter'
            elif pbf> (len_query-60): #pbi cercana a len_query
                section='-C-ter'
            else:
                section=''
        return section
    else:
        return ''

bases_ocupadas_real={}
ORFs_DB= {}


for line in DB_RNA:
    if line.startswith('>'):
        list5= line.split('|')
        ID= list5[0][1:-1] # ID
        organism0= list5[3] #organism
        organism= organism0.split('=')[1]
        gene_product0= list5[4][1:-1]
        gene_product= gene_product0.split('=')[1]
        ORFs_DB[ID]=[gene_product,organism]


gff_RNAs= {}
lastnum={} #dict with last n in contig
for line in BLASTn:
        hit=[]
        line=line.strip()
        line1 = line.split('\t')
        contig= line1[0]
        if contig not in lastnum.keys():
            lastnum[contig]=1
        if contig not in gff_RNAs.keys():
            gff_RNAs[contig]={}
        if contig not in bases_ocupadas_real.keys():
            bases_ocupadas_real[contig]=[]
        homolog = line1[1]
        func_anottation= ORFs_DB[homolog][0]
        organism= ORFs_DB[homolog][1]
        perc_idn=float(line1[2])
        len_alin=int(line1[3])
        pbi_sub=int(line1[6])
        pbf_sub=int(line1[7])
        pbi_query=int(line1[8])
        pbf_query=int(line1[9])
        strand= def_strand(pbi_query, pbf_query)
        query_len=int(line1[12])
        cover= def_coverage(len_alin,query_len)
        mid_base=int((pbi_sub+pbf_sub)/2)
        if pbi_sub not in bases_ocupadas_real[contig] and pbf_sub not in bases_ocupadas_real[contig] and mid_base not in bases_ocupadas_real[contig] and cover>20:
            RNA_type=check_type(func_anottation, data)
            gff_RNAs[contig][lastnum[contig]] = [contig,'BLASTn',RNA_type,pbi_sub, pbf_sub,'.',strand, '.' , 'id='+contig+"_nc"+str(lastnum[contig])+ ';product='+func_anottation]
            lastnum[contig]+=1
            for i in range(pbi_sub,pbf_sub):
                bases_ocupadas_real[contig].append(i)

out_file=input('Write a name for the output file: ')
with open(out_file, 'w') as o:
    for k,v in gff_RNAs.items():
            for kk,vv in v.items():
                GFFclasicotab= ('\t').join(str(n) for n in vv)
                o.write(GFFclasicotab)
                o.write('\n')

BLASTn.close()
DB_RNA.close()


