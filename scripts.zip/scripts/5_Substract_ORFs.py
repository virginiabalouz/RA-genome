import datetime
import collections
import re
from tkinter import *
from tkinter import filedialog
from Bio.Seq import Seq


root = Tk()
a= filedialog.askopenfilename(title= "Select GFF file (Output from script 3):")
archivogff=open(a)
print(a)

#Leo el gff y guardo la info en un diccionario

root = Tk()
b= filedialog.askopenfilename(title= "Select genome FASTA file:")
archivoFasta=open(b)
print(b)

dict_GFF={} #contig:{ID:[pbi,pbf,strand,gffdescription]}
dict_FASTA={}


for line in archivogff:
    if "pseudo"
        line1 = line.split('\t')
        pbi=int(line1[3])
        pbf=int(line1[4])
        strand=line1[6]
        contig= line1[0]
        ID=contig+"_"+line1[3]+"_"+line1[4]
        gffdescription = line1[8]
        if contig not in dict_GFF.keys():
            dict_GFF[contig]={}
        dict_GFF[contig][ID]=[contig,pbi,pbf,strand,gffdescription]


for line in archivoFasta:
    line=line.strip()
    if line.startswith(">"):
        contig=line[1:]
        dict_FASTA[contig]=''
    else:
        dict_FASTA[contig]=dict_FASTA[contig]+line


out_file= input("Nome the output file: ")
with open(out_file, 'w') as o:
    for contig,pseudos in dict_GFF.items():
        for keys in pseudos.keys():
            contig=pseudos[keys][0]
            seq= dict_FASTA[contig][(pseudos[keys][1]-1):pseudos[keys][2]]   # el -1 es porque python empieza en 0 y mis secuencias empiezan en 1
            if pseudos[keys][3] == "-":
                secuencia=Seq(seq)
                seq=secuencia.reverse_complement()
            # print(,keys,pseudos[keys])
            # print(seq)
            o.write(">")
            o.write(keys)
            o.write((';').join(str(n) for n in pseudos[keys]))
            o.write(str(seq))
            o.write('\n')
