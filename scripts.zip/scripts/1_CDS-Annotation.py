
#!usr/bin/env python3
import datetime
import re
import os
from tkinter import *
from tkinter import filedialog

inicio= datetime.datetime.now()

root = Tk()
a= filedialog.askopenfilename(title= "Select FASTA file (output script 0_ORFinORF.py):")
RAORFpred=open(a)
print(a)
#------------------

b= filedialog.askopenfilename(title= "Select BLASTP output file:")
BLASTp=open(b)
# grep='grep -Fc "\n" %s' %b
# os.system(grep)
# num=input('Write number on the screen: ') # these lines allows to follow up the process
Total_lines_RAORFpred=int(num)
#--------------------

c= filedialog.askopenfilename(title= "Select FASTA file used as database in BLASTP:")
TCCann=open(c)
print(c)

cepa=input('Name of the strain:')

scores=input('Elige los scores que debe incluir el gff separados por coma (ej: 0,1,2,3,4,5,6), we used 0,1,2:')
scorelist=scores.split(',')

out = input('Nombre del archivo output con genes anotados: ')
out= open(out,'w+')

out2 = input('Nombre del archivo output con genes no anotados: ')
out2= open(out2,'w+')

print('Se escribira el archivo tipo GFF con los scores %s' % scorelist)

allORFsRA= {}
# crear diccionarios (key es el RA_pred) value es> lista :RA_contig_##, bpi:##, bpf:##, source: ., strand: +o-, bla: .
def add_gene(list,slen,homologTCC,l_ORF,id,cov1,cov2,score):
    slen=slen*3
    slen =str(slen)
    prediccion= allORFsTCC[homologTCC][4] #aca sacamos la funcion del gen
    list.append('homologTCC='+homologTCC)
    list.append('len_homologTCC='+l_ORF)
    list.append('idn='+id)
    list.append('cov1='+cov1+',cov2='+cov2)
    list.append('gene_product='+prediccion)
    list.append('score_pred='+score)
    list.append(allORFsTCC[homologTCC][10])

def writeresultsinfile(v,file_name):
    GFFclasico= v[:8]
    GFFclasicotab= ('\t').join(str(n) for n in GFFclasico)
    descripcion= v[8:]
    l3= (';').join(descripcion)
    file_name.write(GFFclasicotab)
    file_name.write('\t')
    file_name.write(l3)
    file_name.write("\n")


for line2 in RAORFpred:
    if line2.startswith('>'):
        line2.strip()
        line3= line2.split()
        RA_pred= line3[0][1:]
        num_contig= RA_pred.split('_')[1]
        contig_RA= cepa+'_'+ num_contig
        allORFsRA[RA_pred]= []
        range= re.findall('\[[^\]]*\]' ,line2)[0][1:-1]
        bases= range.split('-')
        pb0= int(bases[0])
        pb1= int(bases [1])
        if pb0 < pb1:
            pbi= pb0
            pbf= pb1
            strand = '+'
        else:
            pbi= pb1
            pbf= pb0
            strand = '-'
        largo= pbf-pbi+1
        slargo = str(largo)
        #allORFsRA[RA_pred]= [contig_RA,'getorf','CDS',pbi, pbf,'.', strand, '.']
        allORFsRA[RA_pred]= [contig_RA,'getorf','CDS',pbi, pbf,'.', strand, '.', 'id='+ RA_pred, 'len_ORF='+ slargo]
print('ORFs de archivo a anotar leidos')
RAORFpred.close()

allORFsTCC= {}
for line4 in TCCann:
    if line4.startswith('>'):
        list5= line4.split('|')
        geneTCC= list5[0][1:-1]
        transcript = list5[1][:-1]
        gene = list5[2][:-1]
        organism= list5[3][:-1]
        gene_product0= list5[4][1:-1]
        gene_product= gene_product0.split('=')[1]
        trans_product= list5[5][:-1]
        location= list5[6][:-1]
        prot_length= list5[7][:-1]
        sequence_SO=list5[8][:-1]
        SO=list5[9][:-1]
        is_pseudo=list5[10][1:-1]
        allORFsTCC[geneTCC]= [geneTCC,transcript,gene,organism,gene_product,trans_product,location,prot_length,sequence_SO,SO,is_pseudo]
TCCann.close()
print('ORFs de TCC leidos')
#escanear el blastp filtrado y sumar esa info a la lista de arriba
lineasleidasBLASTp=0
for line1 in BLASTp:
    avancelectura_anterior=(lineasleidasBLASTp/Total_lines_RAORFpred)*100
    avancelectura_anterior=int(avancelectura_anterior)
    lineasleidasBLASTp+=1
    avancelectura=(lineasleidasBLASTp/Total_lines_RAORFpred)*100
    avancelectura=int(avancelectura)
    line1 = line1.split()
    ORF= line1[0]
    bam= ORF.split("_")
    ORFn= bam[0] + "_" + bam[1]
    homologTCC = line1[1]
    id = line1[2]
    qlen= line1[12]
    slen= line1[13]
    len_match=int(line1[3])
    slen= int(slen)
    l_ORF= slen*3
    l_ORF= str(l_ORF)
    qlen= int(qlen)
    id_int= float(id)
    ncov1= (len_match/qlen)*100
    cov1='{:.2f}'.format(ncov1) #vs orf nuevo
    ncov2=(len_match/slen)*100  #vs orfTCC
    cov2='{:.2f}'.format(ncov2)
    slen_plus20=slen*120/100
    slen_minus20=slen*80/100
    for k,v in allORFsRA.items():
        if ORF == k and len(v)<16:
            if '0' in scorelist and id_int == 100 and qlen==slen:
                add_gene(v,slen,homologTCC,l_ORF,id,cov1,cov2,"0")
            elif '1' in scorelist and id_int > 90 and qlen==slen and slen==len_match : #fix 17012023 se llamaba 0 tmb
                add_gene(v,slen,homologTCC,l_ORF,id,cov1,cov2,"1")
            elif '2' in scorelist and id_int > 90 and ncov1>95 and ncov2>95 : #nuevo 030223 y corregido 080323- Quedo 95% despues de charla con Carlos
                add_gene(v,slen,homologTCC,l_ORF,id,cov1,cov2,"2")
            elif '11' in scorelist and id_int == 100 and qlen<=(slen_plus20) and qlen>=(slen_minus20): #Ex 1
                add_gene(v,slen,homologTCC,l_ORF,id,cov1,cov2,"11")
            elif '22' in scorelist and 90 <= id_int < 100 and qlen<=(slen_plus20) and qlen>=(slen_minus20): #Ex 2
                add_gene(v,slen,homologTCC,l_ORF,id,cov1,cov2,"22")
            elif '3' in scorelist and 70 <= id_int < 90 and qlen<=(slen_plus20) and qlen>=(slen_minus20):
                add_gene(v,slen,homologTCC,l_ORF,id,cov1,cov2,"3")
            elif '6' in scorelist and id_int < 70 and qlen<=(slen_plus20) and qlen>=(slen_minus20):
                add_gene(v,slen,homologTCC,l_ORF,id,cov1,cov2,"6")
            elif '4' in scorelist and qlen<=(slen_plus20) and qlen<(slen_minus20):
                add_gene(v,slen,homologTCC,l_ORF,id,cov1,cov2,"4")
            elif '5' in scorelist and qlen>slen:
                add_gene(v,slen,homologTCC,l_ORF,id,cov1,cov2,"5")
    if avancelectura%5==0 and avancelectura!=avancelectura_anterior:
        print('Porcentaje de avance en lectura BLASTp: %s' %avancelectura)

BLASTp.close()

for k,v in allORFsRA.items():
    if len(v) >= 11:
        writeresultsinfile(v,out)

    if len(v) < 11:
        writeresultsinfile(v,out2)

out.close()
out2.close()

print('Todo esto tomo...')
print(datetime.datetime.now() -inicio)
