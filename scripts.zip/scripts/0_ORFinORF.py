
#!usr/bin/env python3

#Este script usa como in un multifasta output de getorf
#Busca las metioninas dentro de cada ORF solo si es maslargo que 40 aa
#Escribe todos los ORFs interiores que sean mayores a 40 aa.
#define el rango OK
import datetime
import os
import sys
import re
from tkinter import *
from tkinter import filedialog
root = Tk()
inicio= datetime.datetime.now()

allORFsRA_todos={}
def ORFsinORFS(x):
    if len(x) > 40:
        n=1
        #print(len (x))
        for match in re.finditer(r'M+',x):
            s=match.start()  #guarda todos los indexes que corresponden con una M
            pieza=x[s:] #Recorto desde la M en adelante
            #pbi = restar_aca_elinicial-s
            if len(pieza)>40:
                allORFsRA_todos[RA_pred][n]={}
                allORFsRA_todos[RA_pred][n]['descripcion_aprox']=allORFsRA_largos[RA_pred]['0']['descripcion']
                allORFsRA_todos[RA_pred][n]['seq']=pieza
                n=n+1
            else:
                continue

a= filedialog.askopenfilename(title= "Select FASTA file (Output getORF EMBOSS):")
RAORFpred=open(a)
print(a)

try:
    RAORFpred = open(RAORFpred)
except:
    print('File not found: %s' % RAORFpred)

allORFsRA_largos= {}
for line2 in RAORFpred:
    if line2.startswith('>'):
        #print(line2)
        line2= line2.strip()
        line3= line2.split()
        #print(line2)
        RA_pred= line3[0][1:]
        allORFsRA_largos[RA_pred]= {}
        allORFsRA_largos[RA_pred]['0']={}
        allORFsRA_largos[RA_pred]['0']['seq']=''
        allORFsRA_largos[RA_pred]['0']['descripcion']= line2
    else:
        line2=line2.strip()
        allORFsRA_largos[RA_pred]['0']['seq']= allORFsRA_largos[RA_pred]['0']['seq']+line2

for RA_pred,v in allORFsRA_largos.items():
    #print(RA_pred)
    allORFsRA_todos[RA_pred]={}
    for kk,vv in v.items():
        #print(kk,vv)
        for kkk,seq in vv.items():
            if kkk=='descripcion':
                if 'REVERSE' in seq:
                    #print(seq)
                    range= re.findall('\[[^\]]*\]' ,seq)[0][1:-1]
                    bases= range.split('-')
                    pb0= int(bases[0])
                    pb1= int(bases [1])
                    pbi= pb1
                    pbf= pb0
                    strand = '-'
                    final=pbf
                    #restar_aca_elinicial=pbi
                else:
                    range= re.findall('\[[^\]]*\]' ,seq)[0][1:-1]
                    bases= range.split('-')
                    pb0= int(bases[0])
                    pb1= int(bases [1])
                    pbi= pb0
                    pbf= pb1
                    strand = '+'
                    final=pbf
                    #restar_aca_elinicial=pbi
            elif kkk=='seq':
                #print(seq)
                #print(restar_aca_elinicial)
                ORFsinORFS(seq)
#


out1= 'output_intermedio_ORFinORF'
out=out1

out= open(out,'w+')

for RA_pred,v in allORFsRA_todos.items():

    for kk,vv in v.items():
        kk=str(kk)
        for clave,detalle in vv.items():
            nombre_CDS='>'+RA_pred+'_'+kk+'  '
            #print(nombre_CDS)
            if clave=='descripcion_aprox':
                nombre_final = nombre_CDS+detalle[1:]
                out.write(nombre_final)
                out.write("\n")
            if clave=='seq':
                out.write(detalle)
                out.write("\n")
out.close()

RAORFpred2= out1
try:
    RAORFpred2=open(RAORFpred2)
except:
    print('File not found: %s' % RAORFpred2)

# path1='/home/viru/'
# print('El path es %s' % path1)
out2 = input('Output file name (FASTA): ')

# out2=path1+out2
out2= open(out2,'w+')

allORFsRA= {}
# crear diccionarios (key es el RA_pred) value es> lista :RA_contig_##, bpi:##, bpf:##, source: ., strand: +o-, bla: .
for line2 in RAORFpred2:
    if line2.startswith('>'):
        line2=line2.strip()
        #print (line2)
        line3= line2.split()
        #print(line2)
        RA_pred= line3[0][1:]
        num_contig= RA_pred.split('_')[1]
        contig_RA= 'RA_'+ num_contig
        allORFsRA[RA_pred]= []
        range= re.findall('\[[^\]]*\]' ,line2)[0][1:-1]
        bases= range.split('-')
        pb0= int(bases[0])
        pb1= int(bases [1])
        if pb0 < pb1:
            pbi= pb0
            pbf= pb1
            strand = '+'
        else:
            pbi= pb1
            pbf= pb0
            strand = '-'
        largo= pbf-pbi+1
        slargo = str(largo)
        allORFsRA[RA_pred]= [contig_RA,'getorf','CDS',pbi, pbf,'.', strand, '.', 'id='+ RA_pred, 'len_ORF_Original='+ slargo]
    else:
        line2=line2.strip()
        #print('---------------------------------------------')
        largo_suborf=len(line2)
        largo_suborf_3=largo_suborf*3
        largo_a_restar=largo-largo_suborf_3
        orientacion= allORFsRA[RA_pred][6]
        if orientacion=='+':
            #print('---------------------------------------------')
            nueva_pbi= pbi+largo_a_restar
            allORFsRA[RA_pred][3]=nueva_pbi
            out2.write('>')
            out2.write(RA_pred)
            out2.write("\t")
            out2.write("[")
            out2.write(str(allORFsRA[RA_pred][3]))
            out2.write(" - ")
            out2.write(str(allORFsRA[RA_pred][4]))
            out2.write("]")
            out2.write("\n")
            out2.write(line2)
            out2.write("\n")
        if orientacion=='-':
            #print('---------------------------------------------')
            nueva_pbf= pbf-largo_a_restar
            #print(largo,largo_a_restar)
            #print(allORFsRA[RA_pred][4])
            allORFsRA[RA_pred][4]=nueva_pbf
            #print(allORFsRA[RA_pred][4])
            out2.write('>')
            out2.write(RA_pred)
            out2.write("\t")
            out2.write("[")
            out2.write(str(allORFsRA[RA_pred][4]))
            out2.write(" - ")
            out2.write(str(allORFsRA[RA_pred][3]))
            out2.write("]")
            out2.write("\n")
            out2.write(line2)
            out2.write("\n")
#elmino archivo intemedio
# rm1='rm ' + path2+out1
rm1='rm ' + out1
rm2='rm ' + out
os.system(rm1)
os.system(rm2)
